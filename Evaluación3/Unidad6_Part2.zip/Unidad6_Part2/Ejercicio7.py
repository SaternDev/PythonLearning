# Lee users.txt y crea homes_check.txt que indique si la carpeta HOME de cada usuario existe (usa pathlib).
# El formato de cada línea debería ser: usuario -> home_path -> estado. El estado puede ser OK o No existe.

diccionario = {

}

with open('users.txt', 'r') as f:
    for linea in f:
        clave, valor = linea.strip().split(',')
        diccionario[clave] = valor

with open('homes_check.txt', 'a') as l:
    for i in diccionario:
        print(i)