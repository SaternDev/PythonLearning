with open('saludo.txt', 'r') as f:
    print(f.read())