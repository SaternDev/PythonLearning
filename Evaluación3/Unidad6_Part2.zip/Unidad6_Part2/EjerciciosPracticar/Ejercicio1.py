with open ('saludo.txt', 'w') as f:
    f.write('Hola mundo')